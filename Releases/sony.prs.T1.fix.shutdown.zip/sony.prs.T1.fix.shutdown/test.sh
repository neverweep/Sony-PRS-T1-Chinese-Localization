#!/bin/sh

PATH=/diag/bin:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin

sleep 1
/diag/bin/epd_fb_test file GC16 FULL /initrd/mnt/sd/Updating_en.bmp
sleep 3

dd if=/dev/mmcblk2 of=/dev/null
sync;sync;sync;

poweroff

# ---------------------------------
# cat > /tmp/shadow << EOF
# root::14975:0:99999:7:::
# bin:*:11851:0:99999:7:::
# daemon:*:11851:0:99999:7:::
# adm:*:11851:0:99999:7:::
# lp:*:11851:0:99999:7:::
# sync:*:11851:0:99999:7:::
# shutdown:*:11851:0:99999:7:::
# halt:*:11851:0:99999:7:::
# mail:*:11851:0:99999:7:::
# news:*:11851:0:99999:7:::
# uucp:*:11851:0:99999:7:::
# operator:*:11851:0:99999:7:::
# games:*:11851:0:99999:7:::
# gopher:*:11851:0:99999:7:::
# ftp:*:11851:0:99999:7:::
# nobody:*:11851:0:99999:7:::
# sshd:!!:11851:0:99999:7:::
# mailnull:!!:11851:0:99999:7:::
# xfs:!!:11851:0:99999:7:::
# ntp:!!:11851:0:99999:7:::
# rpc:!!:11851:0:99999:7:::
# gdm:!!:11851:0:99999:7:::
# rpcuser:!!:11851:0:99999:7:::
# nfsnobody:!!:11851:0:99999:7:::
# nscd:!!:11851:0:99999:7:::
# ident:!!:11851:0:99999:7:::
# radvd:!!:11851:0:99999:7:::
# postgres:!!:11851:0:99999:7:::
# apache:!!:11851:0:99999:7:::
# squid:!!:11851:0:99999:7:::
# named:!!:11851:0:99999:7:::
# pcap:!!:11851:0:99999:7:::
# amanda:!!:11851:0:99999:7:::
# junkbust:!!:11851:0:99999:7:::
# mailman:!!:11851:0:99999:7:::
# mysql:!!:11851:0:99999:7:::
# ldap:!!:11851:0:99999:7:::
# pvm:!!:11851:0:99999:7:::
# user:$1$pJefShJL$CoX8T20vn1g.ug0jZIczM.:11851:0:99999:7:::
# messagebus:!:15:0:99999:7:::
# haldaemon:!:15:0:99999:7:::
# EOF

# chmod +rwx /tmp/shadow
# mount --bind /tmp/shadow /etc/shadow


# /sbin/insmod /lib/modules/2.6.35.3/kernel/drivers/usb/gadget/arcotg_udc.ko
# /sbin/insmod /lib/modules/2.6.35.3/kernel/drivers/usb/gadget/g_serial.ko use_acm=1

# sleep 3
# /sbin/getty -L 9600 ttyGS0 vt102

#reboot 
