#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin
DATA=/tmp/data 
SYSTEM=/tmp/system 

echo Starting $0 `date`

mkdir -p ${DATA}
mkdir -p ${SYSTEM}

for IMAGE in mmcblk2p9 mmcblk2p10
do
   if [ -f ${UPDATE_MP}/tmp/${IMAGE}.img ]
   then
      echo "Updating ${IMAGE}"
      dd if=${UPDATE_MP}/tmp/${IMAGE}.img of=/dev/${IMAGE} bs=1024 conv=notrunc
   fi
done

mount /dev/mmcblk2p9 ${DATA}
mount /dev/mmcblk2p10 ${SYSTEM}

ls -R ${DATA}
echo
echo "---------------------"
echo
ls -R ${SYSTEM}

umount ${DATA}
umount ${SYSTEM}

echo Done $0 `date`
