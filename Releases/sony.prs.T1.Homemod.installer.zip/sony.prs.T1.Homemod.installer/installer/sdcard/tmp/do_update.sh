#!/bin/sh

PATH=/bin:/sbin:/usr/bin:/usr/sbin
DATA=/tmp/data 
SYSTEM=/tmp/system 

echo Starting $0 `date`

mkdir -p ${DATA}
mkdir -p ${SYSTEM}

if [ -f ${UPDATE_MP}/tmp/system.img ]
then
   echo "Expand the /system filesystem"
   dd if=${UPDATE_MP}/tmp/system.img of=/dev/mmcblk2p10 bs=1024 conv=notrunc
fi

mount /dev/mmcblk2p9 ${DATA}
mount /dev/mmcblk2p10 ${SYSTEM}

if [ -f ${SYSTEM}/app/EbookLatinIME4Ebook.apk ]
then
   echo "Make Sony keyboard deselectable"
   mv ${SYSTEM}/app/EbookLatinIME4Ebook.* ${DATA}/app
fi

if [ -d ${UPDATE_MP}/updates/data ]
then
   echo "Updating /data"
   cp -rfp ${UPDATE_MP}/updates/data/* ${DATA}
   cd ${UPDATE_MP}/updates/data
   find data -exec chmod a+rw ${DATA}/{} \;

   if [ -f app/EbookLatinIME4Ebook.apk ]
   then
       echo "Reinstall EbookLatinIME4Ebook.apk with custom signature"
       sed -i '/EbookLatinIME4Ebook/,/<\/package>/ { d }' ${DATA}/system/packages.xml
       chmod -R a+rw ${DATA}/data/com.sony.drbd.ebook.inputmethod.latin
   fi

   cd -
fi

if [ -d ${UPDATE_MP}/updates/system ]
then
   echo "Updating /system"
   cp -rfp ${UPDATE_MP}/updates/system/* ${SYSTEM}
fi


if [ -f ${DATA}/system/packages.xml ]
then
   echo "Get rid of preferred activities in packages.xml"
   sed -i '/<preferred-activities>/,/<\/preferred-activities>/ { /preferred-activities/b; d }' ${DATA}/system/packages.xml

   echo "System signatures"
   sed -i '/uid.system/,/perms/{/uid.system/b;/perms/b;d}' ${DATA}/system/packages.xml
fi

if [ -f ${SYSTEM}/bin/su ]
then
   echo "SuperUser"
   chmod 06755 ${SYSTEM}/bin/su
   mkdir -p ${SYSTEM}/xbin
   ln -fs /system/bin/su ${SYSTEM}/xbin/su
fi

umount ${DATA}
umount ${SYSTEM}

echo Done $0 `date`
